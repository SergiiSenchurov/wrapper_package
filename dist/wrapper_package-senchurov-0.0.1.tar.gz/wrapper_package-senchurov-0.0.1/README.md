# Example Wrapper Package

This is a simple example wrapper package. 
<!-- You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content. -->

For installation use the following command line 
```
pip install "git+https://github.com/SergiiSenchurov/wrapper_package"
```
Build package
```
python3 -m build
```