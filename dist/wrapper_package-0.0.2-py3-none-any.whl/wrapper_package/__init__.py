"""Sample wrapper package"""

__author__ = """Sergii Senchurov"""
__email__ = 'sergii.senchurov@gmail.com'
